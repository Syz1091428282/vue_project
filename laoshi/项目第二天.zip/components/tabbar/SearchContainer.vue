<template>
  <div>
    <h3>Search</h3>
  </div>
</template>
<script>
export default {
  data () {
    return {
    };
  }
}
</script>
<style lang="scss" scoped>
</style>